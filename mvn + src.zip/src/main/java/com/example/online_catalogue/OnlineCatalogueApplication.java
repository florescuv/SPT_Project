package com.example.online_catalogue;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineCatalogueApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineCatalogueApplication.class, args);
	}

}
